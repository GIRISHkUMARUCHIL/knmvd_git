<?php
/**
 * @author Olexandr Zanichkovsky <olexandr.zanichkovsky@zophiatech.com>
 * @package AST
 */

require_once dirname(__FILE__) . '/XmlImportAstLiteral.php';

/**
 * Represents an integer number
 */
class XmlImportAstInteger extends XmlImportAstLiteral
{
  
}
